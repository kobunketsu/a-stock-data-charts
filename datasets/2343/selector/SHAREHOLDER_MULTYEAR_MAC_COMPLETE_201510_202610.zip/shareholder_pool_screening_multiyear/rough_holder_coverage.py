"""Disclosure-only coverage diagnostics; NOT complete250 price-qualified samples."""
from pathlib import Path
import argparse,json,hashlib
import pandas as pd,numpy as np
P=argparse.ArgumentParser();P.add_argument('--source',required=True,type=Path);P.add_argument('--earliest',required=True);P.add_argument('--query-index',type=Path);a=P.parse_args();R=Path(__file__).resolve().parent
m=json.loads((a.source.parent/'MANIFEST.json').read_text());assert m['status']=='complete' and hashlib.sha256(a.source.read_bytes()).hexdigest()==m['sha256']
d=pd.DataFrame(json.loads(a.source.read_text()));d.SECURITY_CODE=d.SECURITY_CODE.astype(str).str.zfill(6)
for c in ['END_DATE','HOLD_NOTICE_DATE']:d[c]=pd.to_datetime(d[c]).dt.normalize()
d['HOLDER_NUM']=pd.to_numeric(d.HOLDER_NUM,errors='coerce')
old=set(pd.read_csv(R/'old_1494.csv',dtype={'code':str}).code)
reg=pd.DataFrame(json.loads((R/'frozen_registry_5577.json').read_text()));listed=set(reg.loc[~reg.SECURITY_NAME_ABBR.str.contains('退',na=False),'SECURITY_CODE'])
x=d[d.SECURITY_CODE.isin(listed)&(d.HOLDER_NUM>0)&(d.END_DATE<=d.HOLD_NOTICE_DATE)].copy()
x=x.sort_values(['SECURITY_CODE','END_DATE','HOLD_NOTICE_DATE']).drop_duplicates(['SECURITY_CODE','END_DATE']);x=x.sort_values(['SECURITY_CODE','HOLD_NOTICE_DATE','END_DATE']).groupby(['SECURITY_CODE','HOLD_NOTICE_DATE'],sort=False).tail(1).sort_values(['SECURITY_CODE','HOLD_NOTICE_DATE'])
f=x.groupby('SECURITY_CODE').END_DATE.cummax().groupby(x.SECURITY_CODE).shift();x=x[x.END_DATE>f.fillna(pd.Timestamp('1900-01-01'))].copy();g=x.groupby('SECURITY_CODE');x['previous_endpoint']=g.END_DATE.shift();x['previous_holder_num']=g.HOLDER_NUM.shift();x['endpoint_gap']=(x.END_DATE-x.previous_endpoint).dt.days;x['notice_lag']=(x.HOLD_NOTICE_DATE-x.END_DATE).dt.days;x['holder_delta']=x.HOLDER_NUM/x.previous_holder_num-1
ok=x.endpoint_gap.between(1,45)&x.notice_lag.between(0,30);e=x[ok].copy();e['year']=e.HOLD_NOTICE_DATE.dt.year
qi={c:{} for c in listed}
if a.query_index:
 idx=json.load(open(a.query_index));qi.update({r['code']:r for r in idx['stocks']})
reports=[];annual=[]
for start in ['2023-10-01','2020-10-01','2015-10-01']:
 file=R/f'pool_from_{start}.csv'
 if start<a.earliest or not file.exists():continue
 p=pd.read_csv(file,dtype={'code':str});pool=set(p.code);added=pool-old
 for kind,codes in [('all_pool',pool),('added_to1494',added)]:
  z=e[e.SECURITY_CODE.isin(codes)];raw=d[d.SECURITY_CODE.isin(codes)];zz=z[z.holder_delta!=0]
  reports.append({'pool_start':start,'group':kind,'stocks':len(codes),'captured_raw_rows':len(raw),'captured_raw_stocks':int(raw.SECURITY_CODE.nunique()),'gap1to45_lag0to30_events':len(z),'gap1to45_lag0to30_stocks':int(z.SECURITY_CODE.nunique()),'nonzero_holder_events':len(zz),'nonzero_holder_stocks':int(zz.SECURITY_CODE.nunique()),'first_eligible_notice':str(z.HOLD_NOTICE_DATE.min().date()) if len(z) else None,'last_eligible_notice':str(z.HOLD_NOTICE_DATE.max().date()) if len(z) else None,'recent_query_price_status':pd.Series([qi[c].get('price_status','unknown') for c in sorted(codes)],dtype=str).value_counts().to_dict(),'recent_display_price_status':pd.Series([qi[c].get('display_price_status','unknown') for c in sorted(codes)],dtype=str).value_counts().to_dict(),'recent_query_holder_status':pd.Series([qi[c].get('holder_status','unknown') for c in sorted(codes)],dtype=str).value_counts().to_dict()})
  for y,t in z.groupby('year'):annual.append({'pool_start':start,'group':kind,'year':int(y),'eligible_disclosure_events':len(t),'eligible_disclosure_stocks':int(t.SECURITY_CODE.nunique()),'nonzero_holder_events':int((t.holder_delta!=0).sum())})
summary={'status':'rough_disclosure_coverage_only','source_notice_start':a.earliest,'source_notice_end':'2026-10-31','no_new_price_data_fetched':True,'not_complete250_samples':True,'limitations':['Source is DET only; early alternative F10 data not added in this screening comparison','First captured disclosure may lack previous period outside captured source','No actual long price-history availability, two-anchor market features or complete250 paths tested for additions','Frozen2026 supplier registry excludes departed stocks; widening windows does not remove survivor/selection bias','Captured raw/event count is not independent sample size or evidence of improved predictive stability'],'results':reports}
(R/f'ROUGH_COVERAGE_FROM_{a.earliest}.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));pd.DataFrame(annual).to_csv(R/f'rough_annual_coverage_from_{a.earliest}.csv',index=False);print(json.dumps(summary,ensure_ascii=False,indent=2))
