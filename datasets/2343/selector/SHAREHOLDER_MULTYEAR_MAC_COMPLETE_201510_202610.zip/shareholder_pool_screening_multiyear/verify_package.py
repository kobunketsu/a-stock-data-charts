from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;m=json.loads((r/'HANDOFF_FILE_MANIFEST.json').read_text())
for x in m['files']:
 b=(r/x['file']).read_bytes();assert len(b)==x['bytes'];assert hashlib.sha256(b).hexdigest()==x['sha256'],x['file']
print('PASS',len(m['files']),'files; no network used')
