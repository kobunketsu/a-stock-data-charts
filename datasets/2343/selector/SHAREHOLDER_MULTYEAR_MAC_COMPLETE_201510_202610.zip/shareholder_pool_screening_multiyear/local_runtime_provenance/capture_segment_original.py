from pathlib import Path
import json,hashlib,urllib.request,urllib.parse,urllib.error,threading,time,concurrent.futures,datetime
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--start',required=True);parser.add_argument('--end',required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
R=args.output;O=R/'raw_capture';O.mkdir(exist_ok=True);stop=threading.Event();lock=threading.Lock();manifest={};errors=[];expected_count=None;stop_reason=None
params=dict(reportName='RPT_HOLDERNUM_DET',columns='SECURITY_CODE,SECURITY_NAME_ABBR,END_DATE,HOLD_NOTICE_DATE,HOLDER_NUM',pageSize=500,filter=f"(HOLD_NOTICE_DATE>='{args.start}')(HOLD_NOTICE_DATE<='{args.end}')",sortColumns='SECURITY_CODE,HOLD_NOTICE_DATE,END_DATE',sortTypes='1,1,1',source='WEB',client='WEB')
def log(*x):print(datetime.datetime.now(datetime.timezone.utc).isoformat(),*x,flush=True)
def get(page,register=True):
 global stop_reason
 if stop.is_set():raise RuntimeError('Global stop after access refusal')
 url='https://datacenter-web.eastmoney.com/api/data/v1/get?'+urllib.parse.urlencode({**params,'pageNumber':page});f=O/(f'page_{page:04d}.json' if register else f'closing_probe_page_{page:04d}.json');saved=f.exists()
 if saved:b=f.read_bytes()
 else:
  for attempt in range(2):
   if stop.is_set():raise RuntimeError('Global stop after access refusal')
   try:
    time.sleep(.3)
    if stop.is_set():raise RuntimeError('Global stop after access refusal')
    with urllib.request.urlopen(url,timeout=45) as res:b=res.read()
    d=json.loads(b);assert d.get('success') and isinstance(d.get('result'),dict),str(d)[:500]
    f.write_bytes(b);break
   except (urllib.error.HTTPError,urllib.error.URLError) as e:
    refused=(isinstance(e,urllib.error.HTTPError) and e.code in [401,403,429]) or any(s in str(e).lower() for s in ['403','401','429','forbidden','denied','unauthorized'])
    if refused:
     stop_reason='access_refusal';stop.set();log('REFUSAL_STOP',url,repr(e));(O/'STOPPED_ON_REFUSAL.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'url':url,'error':repr(e),'no_retry':True},indent=2));raise
    if isinstance(e,urllib.error.HTTPError) and e.code<500:raise
    if attempt:raise
    time.sleep(2)
   except (TimeoutError,ConnectionError):
    if attempt:raise
    time.sleep(2)
 d=json.loads(b);assert d.get('success');rr=d['result']
 if expected_count is not None and rr['count']!=expected_count:
  stop_reason='source_drift';stop.set();(O/'STOPPED_ON_SOURCE_CHANGE.json').write_text(json.dumps({'expected_count':expected_count,'observed_count':rr['count'],'page':page,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2));raise RuntimeError('Source count changed; stop all pages to prevent offset mixing')
 rows=rr['data'];entry={'file':f.name,'page':page,'url':url,'sha256':hashlib.sha256(b).hexdigest(),'rows':len(rows),'count':rr['count'],'pages':rr['pages'],'reused':saved}
 if register:
  with lock:
   manifest[page]=entry;(O/'manifest_progress.json').write_text(json.dumps(sorted(manifest.values(),key=lambda x:x['page']),indent=2))
 return rr
first=get(1);total=first['count'];expected_count=total;pages=first['pages'];log('PROBE',total,pages,len(first['data']),list(first['data'][0]));(O/'PROBE.json').write_text(json.dumps({'count':total,'pages':pages,'page_size_actual':len(first['data']),'columns':list(first['data'][0]),'request':params},indent=2))
with concurrent.futures.ThreadPoolExecutor(2) as ex:
 pending={};it=iter(range(2,pages+1))
 for _ in range(2):
  p=next(it,None)
  if p:pending[ex.submit(get,p)]=p
 while pending:
  done,_=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
  for fu in done:
   p=pending.pop(fu)
   try:
    rr=fu.result();assert rr['count']==total and rr['pages']==pages,'Source count changed while paginating'
    if p%25==0:log('PROGRESS',p,pages)
   except Exception as e:errors.append({'page':p,'error':repr(e)});log('ERROR',p,repr(e))
   if not stop.is_set():
    p=next(it,None)
    if p:pending[ex.submit(get,p)]=p
files=sorted(manifest.values(),key=lambda x:x['page']);complete=not errors and len(files)==pages and sum(x['rows'] for x in files)==total
result={'status':'complete' if complete else 'incomplete','count':total,'pages':pages,'saved_pages':len(files),'saved_rows':sum(x['rows'] for x in files),'files':files,'errors':errors,'stopped_access_refusal':stop_reason=='access_refusal','stop_reason':stop_reason,'request':params}
if complete:
 try:
  closing=get(1,register=False);assert closing['count']==total and closing['pages']==pages;assert closing['data']==first['data'],'First-page content changed during capture';result['closing_probe_count_pages_and_first_page_equal']=True;result['closing_probe_sha256']=hashlib.sha256((O/'closing_probe_page_0001.json').read_bytes()).hexdigest()
 except Exception as e:
  result['status']='incomplete';result['errors'].append({'stage':'closing_probe','error':repr(e)});(O/'CAPTURE_MANIFEST.json').write_text(json.dumps(result,indent=2));raise
 rows=[]
 for x in files:
  b=(O/x['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256'];rows.extend(json.loads(b)['result']['data'])
 keys=[(x['SECURITY_CODE'],x['HOLD_NOTICE_DATE'],x['END_DATE']) for x in rows];assert keys==sorted(keys),'Sort validation failed';result['duplicate_code_notice_endpoint_excess']=len(keys)-len(set(keys));result['exact_row_duplicate_excess']=len(rows)-len({json.dumps(x,sort_keys=True) for x in rows});result['stocks']=len({x['SECURITY_CODE'] for x in rows});assert result['duplicate_code_notice_endpoint_excess']==0,'Duplicate record keys: require review before complete';f=O/'all_raw.json';f.write_text(json.dumps(rows,ensure_ascii=False));result['all_raw_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
(O/'CAPTURE_MANIFEST.json').write_text(json.dumps(result,indent=2));log('FINISH',result['status'],result['saved_rows'],errors)
