from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/'EXPORT_FILE_MANIFEST.json').read_text())
for x in m:
 p=r/x['file'];assert p.is_file() and p.stat().st_size==x['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'],x['file']
print('PASS',len(m),'files')
