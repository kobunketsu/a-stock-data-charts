from pathlib import Path
import pandas as pd,json
R=Path(__file__).resolve().parent;old=pd.read_csv(R/'frozen_old1494_DET_metadata_since2023.csv',dtype={'SECURITY_CODE':str});codes=set(old.SECURITY_CODE);res=[];diffs=[]
for spec in json.loads((R/'SEGMENT_PLAN.json').read_text()):
 if spec['start']<'2023-10-01':continue
 p=R/'segments'/spec['id']/'raw_capture';m=p/'CAPTURE_MANIFEST.json'
 if not m.exists() or json.loads(m.read_text())['status']!='complete':continue
 d=pd.DataFrame(json.loads((p/'all_raw.json').read_text()));d=d[d.SECURITY_CODE.isin(codes)];o=old[old.HOLD_NOTICE_DATE.str[:10].between(spec['start'],spec['end'])];cols=['SECURITY_CODE','HOLD_NOTICE_DATE','END_DATE'];j=o.merge(d,on=cols,how='outer',indicator=True,suffixes=('_old','_new'),validate='one_to_one');both=j._merge=='both';bad=(j._merge!='both')|(both&((j.HOLDER_NUM_old!=j.HOLDER_NUM_new)|(j.SECURITY_NAME_ABBR_old!=j.SECURITY_NAME_ABBR_new)))
 if bad.any():diffs.append(j[bad].assign(segment=spec['id']))
 res.append({'segment':spec['id'],'old1494_old_rows':len(o),'fresh_rows':len(d),'added_keys':int((j._merge=='right_only').sum()),'removed_keys':int((j._merge=='left_only').sum()),'changed_holder_values':int((both&(j.HOLDER_NUM_old!=j.HOLDER_NUM_new)).sum()),'changed_names':int((both&(j.SECURITY_NAME_ABBR_old!=j.SECURITY_NAME_ABBR_new)).sum())})
qa={'status':'completed_segments_only','all_four_segments_complete':len(res)==4,'segments':res,'has_differences':bool(diffs),'limitation':'Checks only frozen1494 DET rows since2023Oct; old full-universe B23 row snapshot unavailable'}
(R/'OLD1494_SOURCE_COMPARISON.json').write_text(json.dumps(qa,indent=2));pd.concat(diffs,ignore_index=True).to_csv(R/'OLD1494_SOURCE_DIFFERENCES.csv',index=False) if diffs else None;print(json.dumps(qa,indent=2))
