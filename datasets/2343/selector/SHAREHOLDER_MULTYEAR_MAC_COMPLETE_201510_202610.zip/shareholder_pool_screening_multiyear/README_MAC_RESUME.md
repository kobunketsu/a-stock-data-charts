# 部分采集断点包：尚不能筛出最终股票池

本包只有302个成功原始页：前三段225页共111621行已完整，2026段77页共38500行尚未完成。2026当前缓存总数47301，缺页78–95（18页）及末次首page复核。随后补2020Oct–2023Sep、2015Oct–2020Sep共10个互斥年段。旧19个研究交付包不在本包中，也不应被修改。

云端2026段page78/79于2026-11-02 09:41:23 UTC遇Tunnel403，两条为在途并发请求；捕获器即时全局停止，没有拒绝重试、后续新页或新段。原拒绝证据保留在原位置和prior_refusal_evidence。不得因为换环境而默认启动；以下有网络命令仅由root依据用户已有Mac授权明确执行。

## Mac操作（先解压，然后进入shareholder_pool_screening_multiyear目录）

```bash
# 纯本地：核包内每文件SHA（含原始302页）
python3 verify_package.py
# 纯本地：再次核断点302页SHA、行数和各段count；默认绝不联网
python3 resume_authorized.py
# 只有root确认用户Mac公开下载授权后才执行这一条
python3 resume_authorized.py --resume-authorized --operator root-mac-public-download
```

恢复入口先验全部302页。显式授权后，将旧active STOP按原字节保存在history/时间戳/，写operator声明并解除旧active halt；不是悄悄删除事故。已完整三段不重抓，2026缓存成功页不覆盖，只补缺页。新的拒绝或源count变化立即停本轮，不自动无限重启。发生新停止后须回报root，不能自行换host、代理或环境。

采集仅用Python标准库（urllib/json/concurrent.futures等），无需pandas/numpy，无自动安装依赖。已在云Python3.12做编译及默认本地SHA核验；未运行Mac网络恢复测试。筛选/粗覆盖评估另需pandas/numpy，requirements-evaluation.txt记录云端版本，不代表Mac环境已经验证。

## 固定源请求

公开主机datacenter-web.eastmoney.com，RPT_HOLDERNUM_DET；字段SECURITY_CODE、SECURITY_NAME_ABBR、END_DATE、HOLD_NOTICE_DATE、HOLDER_NUM；pageSize500，按SECURITY_CODE/HOLD_NOTICE_DATE/END_DATE升序；按HOLD_NOTICE_DATE互斥日期段过滤。最多2并发，每个新请求前0.3秒间隔；普通临时错误最多一次重试。HTTP或包装URLError中的401/403/429全局立即停，不重试；source_drift与access_refusal分别记录。

2026后续页必须仍报47301条/95页；count变即停，不能与旧页拼接。每完整段核页数/总量/唯一(code,notice,endpoint)、全部SHA，末次重新取首page要求count/pages及首page内容一致。服务没有原子快照保证，即使这些检查通过也不能保证后台所有记录同时不变；不要强迫新数据等于旧111472行或1494名单。

SEGMENT_PLAN.json有14段顺序。首4段完成写windows/202310_202610；首8段完成写windows/202010_202610；14段完成写windows/201510_202610。每个目录只有完整后才生成all_raw.json与MANIFEST.json。

## 完整后评估（不提前运行，不抓价格、不重跑收益模型）

```bash
python3 audit_completed.py
python3 evaluate_windows.py --sources windows/202310_202610/all_raw.json --earliest 2023-10-01
# 更长窗口完整后分别运行：
python3 evaluate_windows.py --sources windows/202010_202610/all_raw.json --earliest 2020-10-01
python3 evaluate_windows.py --sources windows/201510_202610/all_raw.json --earliest 2015-10-01
python3 independent_audit/recompute.py 2015-10-01
```

冻结名册5577条，按名称含“退”排除后5554；old_1494.csv用于旧池集合回归，不能强行并入新池。粗股东覆盖脚本支持可选--query-index；本包不含旧查询价格索引，未提供时价格状态为unknown，不是假定有行情。更长筛选窗口不保证样本或关系更稳定。
