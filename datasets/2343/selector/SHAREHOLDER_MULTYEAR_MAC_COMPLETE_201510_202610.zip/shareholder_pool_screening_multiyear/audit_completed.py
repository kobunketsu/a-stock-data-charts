from pathlib import Path
import json,hashlib,collections,datetime
r=Path(__file__).resolve().parent;plan=json.loads((r/'SEGMENT_PLAN.json').read_text());qa=[]
for s in plan:
 o=r/'segments'/s['id']/'raw_capture';p=o/'CAPTURE_MANIFEST.json'
 if not p.exists():continue
 m=json.loads(p.read_text())
 if m['status']!='complete':continue
 rows=[]
 for f in m['files']:
  b=(o/f['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==f['sha256'];d=json.loads(b)['result'];assert d['count']==m['count'] and d['pages']==m['pages'];assert len(d['data'])==f['rows'];rows.extend(d['data'])
 assert len(rows)==m['count'];assert all(s['start']<=x['HOLD_NOTICE_DATE'][:10]<=s['end'] for x in rows);keys=[(x['SECURITY_CODE'],x['HOLD_NOTICE_DATE'],x['END_DATE']) for x in rows];assert len(keys)==len(set(keys)) and keys==sorted(keys)
 b=(o/'all_raw.json').read_bytes();assert hashlib.sha256(b).hexdigest()==m['all_raw_sha256'];assert json.loads(b)==rows
 end=json.loads((o/'closing_probe_page_0001.json').read_text())['result'];first=json.loads((o/'page_0001.json').read_text())['result'];assert end['count']==first['count'] and end['pages']==first['pages'] and end['data']==first['data']
 qa.append({'segment':s['id'],'status':'PASS','rows':len(rows),'pages':m['pages'],'stocks':len({x['SECURITY_CODE'] for x in rows}),'notice_min':min(x['HOLD_NOTICE_DATE'] for x in rows),'notice_max':max(x['HOLD_NOTICE_DATE'] for x in rows),'unique_keys':True,'all_raw_sha256':m['all_raw_sha256'],'null_holder_count':sum(x['HOLDER_NUM'] is None for x in rows),'negative_lag_count':sum(x['END_DATE']>x['HOLD_NOTICE_DATE'] for x in rows)})
out={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed_segments':len(qa),'planned_segments':len(plan),'all_completed_segments_pass':True,'segments':qa,'source_limitation':'Completeness/count/closing-first-page consistency checks do not create an atomic provider snapshot; historical live records can be revised.'};(r/'COMPLETED_SEGMENT_AUDIT.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
