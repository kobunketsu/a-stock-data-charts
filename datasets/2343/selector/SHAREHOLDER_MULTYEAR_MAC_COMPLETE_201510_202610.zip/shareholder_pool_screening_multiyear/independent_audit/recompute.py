from pathlib import Path
from datetime import date,timedelta
from collections import defaultdict
import json,hashlib,csv,sys,calendar
R=Path(__file__).resolve().parents[1];earliest=sys.argv[1];raw=[];segments=[]
for s in json.loads((R/'SEGMENT_PLAN.json').read_text()):
 if s['start']<earliest:continue
 p=R/'segments'/s['id']/'raw_capture';m=json.loads((p/'CAPTURE_MANIFEST.json').read_text());assert m['status']=='complete';rows=[]
 for i,x in enumerate(m['files'],1):
  b=(p/x['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256'];q=json.loads(b)['result'];assert q['count']==m['count'];rows+=q['data']
 a=json.loads((p/'all_raw.json').read_text());assert rows==a and len(a)==m['count'];assert all(s['start']<=x['HOLD_NOTICE_DATE'][:10]<=s['end'] for x in a);raw+=a;segments.append(s['id'])
keys=[(x['SECURITY_CODE'],x['END_DATE'],x['HOLD_NOTICE_DATE']) for x in raw];assert len(keys)==len(set(keys))
registry=json.loads((R/'frozen_registry_5577.json').read_text());allowed={x['SECURITY_CODE'] for x in registry if '退' not in x['SECURITY_NAME_ABBR']};assert len(allowed)==5554
bycode=defaultdict(list);negative=0
for x in raw:
 n=date.fromisoformat(x['HOLD_NOTICE_DATE'][:10]);e=date.fromisoformat(x['END_DATE'][:10]);negative+=e>n
 if x['SECURITY_CODE'] in allowed and e<=n:bycode[x['SECURITY_CODE']].append((n,e))
y,m=map(int,earliest[:7].split('-'));first=y*12+m-1;last=2026*12+9;windows={};metrics=[]
for endidx in range(first+2,last+1):
 sy,sm=divmod(endidx-2,12);ey,em=divmod(endidx,12);lo=date(sy,sm+1,1);hi=date(ey,em+1,calendar.monthrange(ey,em+1)[1]);passed=set()
 for code,observations in bycode.items():
  endpoint={}
  for n,e in observations:
   if lo<=n<=hi:endpoint[e]=min(n,endpoint.get(e,n))
  notice={}
  for e,n in endpoint.items():notice[n]=max(e,notice.get(n,e))
  frontier=date.min;adv=[]
  for n,e in sorted(notice.items()):
   if e>frontier:adv.append(n);frontier=e
  if not adv:continue
  span=(adv[-1]-adv[0]).days;gaps=[(b-a).days for a,b in zip(adv,adv[1:])];ok=len(adv)>=3 and span>=60 and span<=30*(len(adv)-1) and (hi-adv[-1]).days<=30
  if ok:passed.add(code)
  metrics.append({'code':code,'window_end':str(hi),'events':len(adv),'span':span,'last_gap':(hi-adv[-1]).days,'qualifies':ok})
 windows[str(hi)]=passed
old={x['code'] for x in csv.DictReader((R/'old_1494.csv').open())};out={'status':'PASS_INDEPENDENT_RECOMPUTATION','negative_lag_rows':negative,'raw_rows':len(raw),'segments':segments,'alternatives':[]}
for start in ['2024-10-01','2023-10-01','2020-10-01','2015-10-01']:
 if start<earliest:continue
 cutoff=start[:4]+'-12-31';ks=[k for k in windows if k>=cutoff];pool=set().union(*(windows[k] for k in ks));published={x['code'] for x in csv.DictReader((R/f'pool_from_{start}.csv').open())};assert pool==published
 out['alternatives'].append({'start':start,'windows':len(ks),'stocks':len(pool),'added':len(pool-old),'missing_old':sorted(old-pool),'codes_sha256':hashlib.sha256('\n'.join(sorted(pool)).encode()).hexdigest()})
for p in R.glob(f'window_metrics_from_{earliest}.csv'):
 expected={(x['code'],x['window_end']):x for x in csv.DictReader(p.open())};assert len(expected)==len(metrics)
 for x in metrics:
  z=expected[(x['code'],x['window_end'])]
  for k in ['events','span','last_gap']:assert int(z[k])==x[k]
  assert (z['qualifies']=='True')==x['qualifies']
(R/'independent_audit'/f'result_{earliest}.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
