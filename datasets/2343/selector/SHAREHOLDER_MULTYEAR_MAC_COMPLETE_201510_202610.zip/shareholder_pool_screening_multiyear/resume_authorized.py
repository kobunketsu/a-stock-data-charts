"""Default verifies locally. Network starts ONLY with explicit resume flag and operator."""
from pathlib import Path
import argparse,json,hashlib,datetime,subprocess,sys,shutil
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--resume-authorized',action='store_true');ap.add_argument('--operator');a=ap.parse_args()
cp=json.loads((R/'CAPTURE_CHECKPOINT.json').read_text());verified=0
for seg in cp['segments']:
 for f in seg['files']:
  b=(R/f['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==f['sha256'],f'SHA mismatch: {f["file"]}';d=json.loads(b)['result'];assert d['count']==f['source_count']==seg['expected_count'];assert d['pages']==f['source_pages'] and len(d['data'])==f['rows'];verified+=1
assert verified==302
plan=json.loads((R/'SEGMENT_PLAN.json').read_text());oldstop=list((R/'segments').rglob('STOPPED_ON_*.json'))
print(json.dumps({'status':'local_checkpoint_verified','saved_pages':verified,'completed_segment_pages':225,'partial2026_pages':77,'expected2026_count':47301,'missing2026_pages':list(range(78,96)),'old_halts':[str(p.relative_to(R)) for p in oldstop],'network_will_start':a.resume_authorized},indent=2),flush=True)
if not a.resume_authorized:sys.exit(0)
assert a.operator and a.operator.strip(),'Explicit operator is required; no implicit resumption'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');history=R/'history'/stamp;history.mkdir(parents=True,exist_ok=False)
for f in oldstop:
 dest=history/f.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest);assert dest.read_bytes()==f.read_bytes();f.unlink()
(history/'RESUME_DECLARATION.json').write_text(json.dumps({'utc':stamp,'operator':a.operator,'explicit_resume_flag':True,'original302_sha_verified':True,'prior_halts_preserved':[str(p.relative_to(R)) for p in oldstop],'scope':'Only missing2026 pages78..95+closing probe then10 mutually exclusive earlier segments','prior_cloud_refusal_acknowledged':True},indent=2))
for n,seg in enumerate(plan):
 assert not list((R/'segments').rglob('STOPPED_ON_*.json')),'New stop marker: no next segment permitted'
 out=R/'segments'/seg['id'];out.mkdir(parents=True,exist_ok=True);mf=out/'raw_capture/CAPTURE_MANIFEST.json'
 if not(mf.exists() and json.loads(mf.read_text())['status']=='complete'):
  subprocess.run([sys.executable,str(R/'capture_segment.py'),'--start',seg['start'],'--end',seg['end'],'--output',str(out)],check=True)
 m=json.loads(mf.read_text());assert m['status']=='complete' and not m['errors'],'Incomplete segment; stop without automatic restart'
 print('SEGMENT_DONE',seg['id'],m['count'],flush=True)
 if n in [3,7,13]:
  window={3:'202310_202610',7:'202010_202610',13:'201510_202610'}[n];rows=[];sources=[]
  for prior in plan[:n+1]:
   p=R/'segments'/prior['id']/'raw_capture/all_raw.json';d=json.loads(p.read_text());rows.extend(d);sources.append({'segment':prior['id'],'rows':len(d),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  keys=[(x['SECURITY_CODE'],x['HOLD_NOTICE_DATE'],x['END_DATE']) for x in rows];assert len(keys)==len(set(keys));rows.sort(key=lambda x:(x['SECURITY_CODE'],x['HOLD_NOTICE_DATE'],x['END_DATE']));o=R/'windows'/window;o.mkdir(parents=True,exist_ok=True);p=o/'all_raw.json';p.write_text(json.dumps(rows,ensure_ascii=False));(o/'MANIFEST.json').write_text(json.dumps({'status':'complete','rows':len(rows),'stocks':len({x['SECURITY_CODE'] for x in rows}),'unique_keys':True,'sources':sources,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'warning':'Live source revisions possible; do not force legacy counts'},indent=2));print('WINDOW_READY',window,len(rows),flush=True)
print('ALL_SEGMENTS_COMPLETE',flush=True)
