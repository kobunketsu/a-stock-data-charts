from pathlib import Path
import json,hashlib,argparse
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();r=a.root
m=json.loads((r/'CAPTURE_EXPORT_MANIFEST.json').read_text())
for x in m['files']:
 f=r/'capture_handoff'/x['path'];assert f.is_file() and f.stat().st_size==x['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256'],x['path']
print('PASS',len(m['files']),'complete-capture files; no network')
