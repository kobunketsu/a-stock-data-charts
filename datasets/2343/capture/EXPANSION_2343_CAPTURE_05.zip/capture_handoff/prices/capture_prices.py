"""Local Mac collector. Dry-run by default; Python stdlib + Node. Never overwrites frozen files."""
from pathlib import Path
import ssl
import argparse,csv,json,hashlib,urllib.request,urllib.error,socket,time,threading,concurrent.futures,subprocess,bisect,math,datetime,re,os
P=argparse.ArgumentParser(description=__doc__);P.add_argument('--execute',action='store_true');P.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'price_capture');P.add_argument('--global-stop-file',type=Path,default=Path(__file__).resolve().parent.parent/'GLOBAL_STOP.json');P.add_argument('--workers',type=int,default=4);P.add_argument('--max-new',type=int);a=P.parse_args();assert 1<=a.workers<=4
HERE=Path(__file__).resolve().parent;O=a.output.resolve();rows=list(csv.DictReader((HERE/'added_849.csv').open()));assert len(rows)==849 and len({r['code'] for r in rows})==849
GLOBAL_STOP=a.global_stop_file.resolve();STOP=threading.Event();LOCK=threading.Lock();START='2009-01-01';END='2026-10-30'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def atomic_new(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():
  assert p.read_bytes()==b,'Existing file differs; no overwrite: '+p.name
  return
 tmp=p.with_name(p.name+'.tmp');tmp.write_bytes(b)
 if p.exists():tmp.unlink();raise RuntimeError('Concurrent existing destination')
 tmp.replace(p)
def refusal(e):
 seen=set();todo=[e]
 while todo:
  x=todo.pop()
  if id(x) in seen:continue
  seen.add(id(x))
  if getattr(x,'code',None) in [401,403,429] or re.search(r'(?<!\d)(401|403|429)(?!\d)',str(x)) or any(t in str(x).lower() for t in ['tunnel connection failed','tunnel refused','proxy authentication required','forbidden','denied','unauthorized']):return True
  todo += [v for v in [getattr(x,'reason',None),getattr(x,'__cause__',None),getattr(x,'__context__',None)] if v is not None]
 return False
def globally_stopped():
 if GLOBAL_STOP.exists():STOP.set()
 return STOP.is_set()
def write_global_stop(url,e):
 GLOBAL_STOP.parent.mkdir(parents=True,exist_ok=True)
 try:fd=os.open(GLOBAL_STOP,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 except FileExistsError:return
 with os.fdopen(fd,'w') as f:json.dump({'source':'prices','time':now(),'url':url,'error':str(e),'action':'STOP_ALL_SOURCES; fresh authorization required'},f,indent=2)
def get(url):
 for attempt in range(2):
  if globally_stopped():raise RuntimeError('not_attempted_after_refusal')
  time.sleep(.3)
  if globally_stopped():raise RuntimeError('not_attempted_after_refusal')
  try:
   with urllib.request.urlopen(url,timeout=30) as r:return r.read()
  except Exception as e:
   if refusal(e):
    STOP.set();write_global_stop(url,e)
    with LOCK:
     if not (O/'STOPPED_ON_REFUSAL.json').exists():atomic_new(O/'STOPPED_ON_REFUSAL.json',json.dumps({'time':now(),'url':url,'error':str(e),'action':'STOP; no automatic restart; obtain fresh authorization before any later retry'},indent=2).encode())
    raise
   transient=isinstance(e,(TimeoutError,socket.timeout,ssl.SSLEOFError)) or isinstance(e,urllib.error.HTTPError) and 500<=e.code<600 or isinstance(e,urllib.error.URLError) and isinstance(e.reason,(TimeoutError,socket.timeout,ssl.SSLEOFError))
   if transient and attempt==0:time.sleep(1);continue
   raise

def validate_success(c):
 p=O/'success'/f'{c}.json'
 if not p.exists():return False
 j=json.loads(p.read_text());assert j['status'] in ['ok','empty_no_price']
 for kind,key in [('raw_prices/'+c+'_full.js','raw_sha256'),('raw_prices/'+c+'_hfq.txt','factor_sha256')]:assert sha(O/kind)==j[key],f'Checkpoint SHA mismatch {c}'
 if j['status']=='ok':assert sha(O/'prices'/f'{c}.csv')==j['csv_sha256']
 return True

def work(t):
 c=t['code'];symbol=('sh' if c.startswith('6') else 'bj' if c.startswith(('92','8','4')) else 'sz')+c
 u=f'https://finance.sina.com.cn/realstock/company/{symbol}/hisdata/klc_kl.js';fu=f'https://finance.sina.com.cn/realstock/company/{symbol}/hfq.js';j={'code':c,'name':t.get('name',''),'started_at':now(),'price_url':u,'factor_url':fu,'saved_start':START,'saved_end':END}
 try:
  if globally_stopped():raise RuntimeError('not_attempted_after_refusal')
  rp=O/'raw_prices'/f'{c}_full.js';fp=O/'raw_prices'/f'{c}_hfq.txt'
  for p,url in [(rp,u),(fp,fu)]:
   if not p.exists():atomic_new(p,get(url))
  raw=json.loads(subprocess.check_output(['node',str(HERE/'sina_decoder.js'),str(rp)],timeout=60,stderr=subprocess.PIPE));text=fp.read_text();obj=json.JSONDecoder().raw_decode(text[text.index('{'):])[0];assert isinstance(obj.get('data'),list),'Missing factor data';factors=sorted((r['d'],float(r['f'])) for r in obj['data']);assert factors or obj.get('total') in [0,'0'],'Missing factor data';assert all(math.isfinite(f) and f>0 for _,f in factors);dates=[d for d,f in factors];valid=[];saved=[]
  for r in raw:
   d=r['date'][:10];v={k:float(r[k]) for k in ['open','high','low','close','volume']};assert all(math.isfinite(x) for x in v.values()),'Nonfinite raw values'
   if min(v[k] for k in ['open','high','low','close'])<=0:continue
   valid.append(d)
   if not START<=d<=END:continue
   ix=bisect.bisect_right(dates,d)-1
   if factors and ix<0:raise ValueError('Missing effective factor at '+d)
   f=factors[ix][1] if ix>=0 else 1.
   saved.append({'date':d,**{k:v[k]*f for k in ['open','high','low','close']},'volume':v['volume'],'adjustment_factor':f,**{'raw_'+k:v[k] for k in ['open','high','low','close']}})
  saved.sort(key=lambda r:r['date']);assert len({r['date'] for r in saved})==len(saved),'Duplicate dates'
  j.update(raw_sha256=sha(rp),factor_sha256=sha(fp),raw_valid_price_rows=len(valid),raw_first_valid_date=min(valid) if valid else None,raw_last_valid_date=max(valid) if valid else None,count_price_rows_before_saved_start=sum(d<START for d in valid),count_valid_rows_through_end=sum(d<=END for d in valid),rows=len(saved),first_date=saved[0]['date'] if saved else None,last_date=saved[-1]['date'] if saved else None,status='ok' if saved else 'empty_no_price')
  if saved:
   import io
   s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=list(saved[0]));w.writeheader();w.writerows(saved);dest=O/'prices'/f'{c}.csv';atomic_new(dest,s.getvalue().encode());j['csv_sha256']=sha(dest)
  j['completed_at']=now();atomic_new(O/'success'/f'{c}.json',json.dumps(j,ensure_ascii=False,indent=2).encode())
 except Exception as e:
  if 'Duplicate dates' in str(e):STOP.set();write_global_stop(u,e)
  j.update(status='not_attempted_after_refusal' if STOP.is_set() and 'not_attempted' in str(e) else 'fetch_error' if isinstance(e,(urllib.error.URLError,TimeoutError,socket.timeout)) else 'parse_error',error=type(e).__name__+': '+str(e),completed_at=now())
 with LOCK:
  with (O/'attempts.jsonl').open('a') as f:f.write(json.dumps(j,ensure_ascii=False)+'\n')
  print(json.dumps({'code':c,'status':j['status'],'rows':j.get('rows'),'error':j.get('error')},ensure_ascii=False),flush=True)
 return j

if not a.execute:
 print(json.dumps({'mode':'DRY_RUN_NO_NETWORK','stocks':len(rows),'workers':a.workers,'output':str(O),'start':START,'end':END},indent=2));raise SystemExit()
O.mkdir(parents=True,exist_ok=True)
if GLOBAL_STOP.exists() or (O/'STOPPED_ON_REFUSAL.json').exists():raise SystemExit('Prior refusal: stopped. No automatic resume; fresh authorization and review required.')
subprocess.run(['node','--version'],check=True);todo=[r for r in rows if not validate_success(r['code'])]
if a.max_new is not None:assert a.max_new>0;todo=todo[:a.max_new]
with concurrent.futures.ThreadPoolExecutor(a.workers) as pool:results=list(pool.map(work,todo))
status={r['code']:json.loads((O/'success'/f"{r['code']}.json").read_text()) if (O/'success'/f"{r['code']}.json").exists() else {'code':r['code'],'status':'pending_or_failed'} for r in rows}
for j in results:status[j['code']]=j
summary={'ended_at':now(),'stop_on_refusal':STOP.is_set(),'planned':849,'attempted_this_run':len(todo),'status_counts':{k:sum(x['status']==k for x in status.values()) for k in sorted({x['status'] for x in status.values()})},'results':list(status.values())};(O/'manifest.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='results'},indent=2));raise SystemExit(2 if STOP.is_set() or any(j['status'] not in ['ok','empty_no_price'] for j in results) else 0)
