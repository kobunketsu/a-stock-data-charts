# 新增849股全历史行情：Mac采集交接

新增池2343股=原冻结1494股+本名单849股。原1494数据不改；本程序只抓新增名单。四处可用完整历史raw缓存检查新增完整full+factor为0。5554股查询只有展示窗口数据，不能替代全历史。云端本次没有访问行情源。

## 环境与启动
Python标准库、已安装Node；不需要pandas/numpy或额外安装。把本文件夹放Mac本地；终端进入文件夹：

```sh
python3 test_offline.py
python3 capture_prices.py --output ./price_capture
# 上条仅显示计划，不联网。先小批验证公开源：
python3 capture_prices.py --execute --output ./price_capture --workers 4 --max-new 4
# 核小批成功后继续，同一个输出目录会SHA校验并跳过成功股票：
python3 capture_prices.py --execute --output ./price_capture --workers 4
```

不得改名单抓旧1494。并发最大4，每个请求前至少0.3秒等待；请求超时30秒，超时或5xx最多重试一次。HTTP401/403/429及嵌套URLError中的相同拒绝均触发全局停止；已在途请求可能结束，未开始请求不再发起。默认两采集器共用上一级GLOBAL_STOP.json（可用--global-stop-file显式指向同一文件）。每次请求前检查共同停止文件，任一路遇拒绝即原子独占写入（不覆盖首个拒绝记录），另一路不得发起后续请求，允许已在途请求结束保存。GLOBAL_STOP.json或STOPPED_ON_REFUSAL.json存在时后续启动拒绝运行，需重新取得授权和检查，不能擅自删除标记换域名、代理或绕过。程序不更换来源、不关闭TLS。

## 输出与完整性
- raw_prices：原Sina full压缩JS与hfq因子原文，按有效日期复权。
- prices：2009-01-01至2026-10-30规范CSV，raw OHLC、复权OHLC、volume、adjustment_factor；缺价格/因子不伪造。
- success：每股成功或empty_no_price的SHA检查点；成功后复跑核SHA并跳过。既存文件不同则报错，不覆盖。
- attempts.jsonl、manifest.json：各股状态，区分ok、empty_no_price、fetch_error、parse_error、拒绝后未尝试与尚未完成。
- raw_valid_price_rows、count_price_rows_before_saved_start、count_valid_rows_through_end及实际最早/最晚有效行情日期记录完整历史计数。**最早有价日期不是核验过的上市日期。**

接口不可避免返回全部历史，但规范行情只保存指定日期范围；原文保留用于审计。需要输出目录完整返回，不只CSV。名单849必须最终全部有明确终态；pilot未处理项属于pending，不能称采集完毕。

## 规模与时间
根据此前同源294股8.3分钟，仅估849股25–45分钟，建议留1小时；Mac实际网络尚未验证。按已恢复1494样本外推：新增规范CSV约200–350MB，原文约20–40MB，压缩约70–130MB；粗估需额外1GB磁盘余量，具体随历史长度变化。原1494冻结数据无需重复复制。

来源：https://finance.sina.com.cn/stock/ 。具体公开请求URL逐股保存在manifest。采集器只写本地输出，不上传、不发布、不自动重训练。原始供应商内容及使用权限制仍适用。
