"""Offline export of capture files; never accesses network or accepts partial as complete."""
from pathlib import Path
import argparse,json,hashlib,zipfile
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=a.root.resolve();o=a.output.resolve();o.mkdir(parents=True,exist_ok=True)
price=r/'prices/price_capture/manifest.json';holder=r/'holders/CAPTURE_COMPLETE.json'
assert price.exists() and holder.exists(),'Both collectors must finish and write their manifests first'
pj=json.loads(price.read_text());hj=json.loads(holder.read_text());assert not pj['stop_on_refusal'] and pj['planned']==849 and sum(pj['status_counts'].get(x,0) for x in ['ok','empty_no_price'])==849,'Price capture not terminal-success';assert hj['status']=='complete' and not hj['errors'],'Holder capture incomplete'
files=[x for x in sorted(r.rglob('*')) if x.is_file() and '__pycache__' not in x.parts and x.suffix not in ['.log','.pyc'] and not x.name.startswith('.') and not x.is_relative_to(o)]
entries=[{'path':str(x.relative_to(r)),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in files]
# Keep uncompressed part payload under 40MiB; ZIP overhead stays under requested45MiB.
parts=[];batch=[];size=0
for x in files:
 if x.stat().st_size>40*1024**2:raise RuntimeError('One file exceeds safe part size; explicit review needed: '+x.name)
 if batch and size+x.stat().st_size>40*1024**2:parts.append(batch);batch=[];size=0
 batch.append(x);size+=x.stat().st_size
if batch:parts.append(batch)
archives=[]
for i,part in enumerate(parts,1):
 z=o/f'EXPANSION_2343_CAPTURE_{i:02d}.zip';assert not z.exists(),'Never overwrite existing capture archive'
 with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
  for x in part:f.write(x,'capture_handoff/'+str(x.relative_to(r)))
 with zipfile.ZipFile(z) as f:assert f.testzip() is None
 assert z.stat().st_size<45*1024**2
 archives.append({'file':z.name,'bytes':z.stat().st_size,'sha256':hashlib.sha256(z.read_bytes()).hexdigest()})
(o/'CAPTURE_EXPORT_MANIFEST.json').write_text(json.dumps({'status':'capture_complete_not_model_audited','added_stocks':849,'files':entries,'archives':archives},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'capture_complete_not_model_audited','archives':archives},ensure_ascii=False,indent=2))
