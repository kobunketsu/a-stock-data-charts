"""Preserve a stopped incomplete capture; no network and no complete-status promotion."""
from pathlib import Path
import json,hashlib,zipfile,re,datetime
R=Path(__file__).resolve().parent;O=R.parent/'capture_checkpoint_export';assert not O.exists();O.mkdir()
assert (R/'GLOBAL_STOP.json').exists();execution=json.loads((R/'SUPERVISED_EXECUTION.json').read_text());assert execution['all_collectors_terminated']
qa=json.loads((R/'OFFLINE_CAPTURE_QA.json').read_text());assert qa['status']=='PASS_AVAILABLE_DATA'
files=[p for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and not p.name.startswith('.') and p.suffix!='.pyc']
parts=[];batch=[];size=0
for p in files:
 assert p.stat().st_size<=40*1024**2,p.name
 if batch and size+p.stat().st_size>40*1024**2:parts.append(batch);batch=[];size=0
 batch.append(p);size+=p.stat().st_size
if batch:parts.append(batch)
manifest=[];archives=[];redactions=[]
patterns=[rb'/' + rb'Users/',rb'/' + rb'home/oai/',rb'/' + rb'workspace/',rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY',rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{30,}']
for i,part in enumerate(parts,1):
 name=f'EXPANSION_2343_CHECKPOINT_{i:02d}.zip';dest=O/name
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,6) as z:
  for p in part:
   b=p.read_bytes();new=b.replace((str(R)+'/').encode(),b'<CAPTURE_ROOT>/').replace((str(R.parent)+'/').encode(),b'<WORKSPACE>/');rel=p.relative_to(R).as_posix()
   if b!=new:
    assert not ('raw_prices/' in rel or rel.startswith('prices/price_capture/prices/') or re.search(r'/page_\d+\.json$|/closing_probe\.json$',rel)),'Raw data must not be changed'
    redactions.append({'file':rel,'original_sha256':hashlib.sha256(b).hexdigest(),'exported_sha256':hashlib.sha256(new).hexdigest()})
   assert not any(re.search(pattern,new) for pattern in patterns),rel
   z.writestr('capture_handoff/'+rel,new);manifest.append({'file':rel,'part':name,'bytes':len(new),'sha256':hashlib.sha256(new).hexdigest(),'source_sha256':hashlib.sha256(b).hexdigest(),'path_redacted':b!=new})
 with zipfile.ZipFile(dest) as z:assert z.testzip() is None
 assert dest.stat().st_size<45*1024**2
 archives.append({'file':name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()});print('PART_DONE',name,flush=True)
summary={'status':'INCOMPLETE_STOPPED_CHECKPOINT_NOT_2343_READY','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'price_ok':qa['price_validated_stocks'],'price_rows':qa['price_rows'],'price_gap':['002107 factor response'],'holder_completed_jobs':qa['holder_complete_jobs'],'holder_planned_jobs':18,'holder_gap':'F10_full_08 page4 (315rows) andclosing probe','actual_HTTP_refusal_or_source_drift':False,'stop_reason':'Supervisor escalated one ordinary SSL EOF price failure into shared collector_exit_nonzero stop.','global_stop_preserved':True,'all_collectors_terminated':True,'restore':'Extract all DATA ZIPs into one empty folder; verify each file against FILE_MANIFEST.json. Original handoff verification is historical; runtime fixes and archived stops are retained.','not_complete_model_inputs':True}
(O/'CHECKPOINT_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(O/'FILE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');(O/'ARCHIVES.json').write_text(json.dumps(archives,indent=2)+'\n');(O/'PATH_REDACTIONS.json').write_text(json.dumps(redactions,ensure_ascii=False,indent=2)+'\n')
(O/'README.md').write_text('''# 2343扩池未完成断点保全\n\n848股价格与17批股东完成；当前没有真实HTTP拒绝或source修订。普通SSL EOF失败触发了监督器过宽的非零退出全局停机，最后F10批被中断。GLOBAL_STOP仍保留，所有采集进程退出，未恢复任何请求。\n\n最小剩余：002107因子、F10_full_08第4页315行和closing probe。已成功价格/页应复用，不重抓。运行脚本、原脚本、已审别名修复、监督器分类修复及全部失败现场都已保存。不得因本包为断点而把它称完整2343输入或绕过未来真实拒绝。\n\n所有DATA ZIP为普通独立ZIP，解压合并同名capture_handoff目录；按FILE_MANIFEST逐文件核SHA。原始raw/factor/CSV/源页均未改，日志和少量元数据私人路径仅在导出副本净化，source/package双SHA及净化记录保留。无模型、GitHub、网站或网络/安全设置更改。第三方资料不新增开源或商业转售授权。\n''')
meta=O/'EXPANSION_2343_CHECKPOINT_META.zip'
with zipfile.ZipFile(meta,'w',zipfile.ZIP_DEFLATED,6) as z:
 for n in ['CHECKPOINT_SUMMARY.json','FILE_MANIFEST.json','ARCHIVES.json','PATH_REDACTIONS.json','README.md']:z.write(O/n,n)
with zipfile.ZipFile(meta) as z:assert z.testzip() is None
receipt=[{'file':meta.name,'bytes':meta.stat().st_size,'sha256':hashlib.sha256(meta.read_bytes()).hexdigest()}]+archives
(O/'UPLOAD_FILES.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'files':len(manifest),'parts':len(receipt),'bytes':sum(x['bytes'] for x in receipt),'summary':summary}),flush=True)
