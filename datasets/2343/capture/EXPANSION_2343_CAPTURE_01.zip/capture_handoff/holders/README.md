# 2343池：新增849股股东历史捕获交接（未执行网络）

旧1494全部冻结，不重新请求。新增名单added_849.csv已校验849，完整池2343包含旧1494。复用完整筛选快照2015-10-01至2026-10-31中新增849的69054条DET记录，已打包为672437字节gzip并附SHA；849均有记录，但不能据此声称供应商不存在缺失endpoint。

新增网络范围：
- DET：仅2009-01-01至2015-09-30；不重复抓2015+已有DET。
- F10：2009-01-01至2026-10-31，保留原HOLDER_A_NUM/NOTICE_DATE及其他字段；只用于补DET缺endpoint和口径核验，不以TOTAL回填A。
- 各源按100代码组，共9组/源、18组。每组首probe报告精确count/pages，末probe核count/pages/首page内容；分页500，代码/公布日/统计日升序。没有进行网络probe，总请求数未知；至少18首probe+18末probe，另外每组pages-1。不能把估计当已抓到的数据。

## Mac（由root统一执行；本交接未在Mac联网测试）

```bash
cd /path/to/shareholder_model_2343/capture_handoff/holders
# 默认纯本地核复用gzip及已保存成功页，并列请求计划
python3 capture_early.py
# 首次root授权执行；普通断点续采也用此命令，但不能解除已有拒绝
python3 capture_early.py --execute --operator root-mac-authorized
```

只用Python标准库。完整筛选原66MB文件无需再次读取，复用gzip已由其完整SHA校验后的本地数据抽取。未来合并时旧研究根传入实际Mac `.../up80_recovery/research`，不写死目录、不改旧输入。

若出现拒绝：立即停止，不要机械重跑上述命令。共享拒绝标记默认是`capture_handoff/GLOBAL_STOP.json`，可用`--global-stop-file`显式指定；price与holder必须共用。每次请求/重试前及请求间隔后检查。401/403/429及包装URLError拒绝写共享首事故（不覆盖）并停；两条已在途请求可保存成功响应，但不得派发下一请求。普通临时错误最多安全重试一次，未知错误停止。

只有root另获后续授权时才可用独立flag：
```bash
python3 capture_early.py --resume-after-refusal-authorized --operator root-new-authorization
```
该flag不是此次授权的自动延伸。它先核成功页SHA，再归档旧标记，记录新operator；root还需协调price端统一恢复。`--execute`永远不能清旧STOP。源count/pages或首page内容漂移也停止，不混拼，不无限自动重启。

归档原始页、逐页SHA/URL、每组COMPLETE和总CAPTURE_COMPLETE。成功页不覆盖，重入先校SHA/count。未完整捕获时禁止合并或运行模型。模型人数采用DET优先；F10只补缺(code,END_DATE)，A为空隔离；日期异常隔离；既有5列DET的TOTAL_A_SHARES未知留空，不能由平均持股反推。
