"""Public historical metadata capture. Default is OFFLINE; never fetch old1494."""
from pathlib import Path
import argparse,csv,json,gzip,hashlib,urllib.request,urllib.parse,urllib.error,threading,concurrent.futures,time,datetime,shutil
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--resume-after-refusal-authorized',action='store_true');p.add_argument('--operator');p.add_argument('--global-stop-file',type=Path,default=R.parent/'GLOBAL_STOP.json');a=p.parse_args();G=a.global_stop_file;O=R/'captured';O.mkdir(exist_ok=True);stop=threading.Event();lock=threading.Lock();stop_reason=None
codes=sorted(x['code'] for x in csv.DictReader((R/'added_849.csv').open()));assert len(codes)==len(set(codes))==849
qa=json.loads((R/'REUSE_QA.json').read_text());assert hashlib.sha256(gzip.decompress((R/'reused_added849_DET_metadata.json.gz').read_bytes())).hexdigest()==qa['reused_added849_sha256']
jobs=[]
for table,end,kind,field in [('RPT_HOLDERNUM_DET','2015-09-30','DET_early','HOLD_NOTICE_DATE'),('RPT_F10_EH_HOLDERNUM','2026-10-31','F10_full','NOTICE_DATE')]:
 for i in range(0,len(codes),100):jobs.append({'id':f'{kind}_{i//100:02d}','table':table,'start':'2009-01-01','end':end,'datefield':field,'codes':codes[i:i+100]})
(R/'REQUEST_PLAN.json').write_text(json.dumps({'jobs':jobs,'first_probes':18,'closing_probes':18,'page_size':500,'network_authorized_flag':a.execute or a.resume_after_refusal_authorized},indent=2))
def result(d):
 if d.get('code')==9201 and not d.get('result'):return {'count':0,'pages':0,'data':[]}
 assert d.get('success') and isinstance(d.get('result'),dict),str(d)[:400]
 return d['result']
# Reentry verifies every successful cached page against its own persisted journal first.
for manifest in O.glob('*/page_manifest.json'):
 for x in json.loads(manifest.read_text()):
  b=(manifest.parent/x['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256'];d=result(json.loads(b));assert d['count']==x['count'] and d['pages']==x['pages'] and len(d['data'] or [])==x['rows']
print(json.dumps({'status':'offline_ready','added_stocks':849,'reused_rows':qa['reuse_rows'],'jobs':18,'first_probes':18,'closing_probes':18,'total_pages':'Not measured; firstprobe reports exact count/pages for each batch','network':a.execute or a.resume_after_refusal_authorized}),flush=True)
if not (a.execute or a.resume_after_refusal_authorized):raise SystemExit(0)
assert a.operator and a.operator.strip(),'Explicit operator required'
prior_stops=list(O.rglob('STOPPED_*.json'))+([G] if G.exists() else [])
assert not prior_stops or a.resume_after_refusal_authorized,'Prior halt remains: require new root authorization and separate resume flag; --execute cannot clear it'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');hist=R/'history'/stamp;hist.mkdir(parents=True,exist_ok=False)
for f in prior_stops:
 dst=hist/('GLOBAL_STOP.json' if f==G else f.relative_to(O));dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst);f.unlink()
(hist/'AUTHORIZATION.json').write_text(json.dumps({'operator':a.operator,'initial_execute':a.execute,'separate_resume_after_refusal_flag':a.resume_after_refusal_authorized,'utc':stamp,'successful_page_sha_rechecked':True},indent=2))
def halt(reason,job,url,error):
 global stop_reason
 stop_reason=reason;stop.set();event={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':reason,'job':job,'url':url,'error':str(error),'no_automatic_restart':True};
 if reason in ['access_refusal','source_drift','validation_anomaly']:
  G.parent.mkdir(parents=True,exist_ok=True)
  try:
   with G.open('x') as gf:json.dump(event,gf,indent=2)
  except FileExistsError:pass
 (O/f'STOPPED_{reason}.json').write_text(json.dumps(event,indent=2));print(json.dumps(event),flush=True)
def get(j,page,folder,records,expected=None,closing=False):
 if stop.is_set() or G.exists():stop.set();raise RuntimeError('Global stop; no new request')
 field=j['datefield'];fil='(SECURITY_CODE in ('+','.join('"'+x+'"' for x in j['codes'])+'))'+f"({field}>='2009-01-01')({field}<='{j['end']}')";params=dict(reportName=j['table'],columns='ALL',pageSize=500,pageNumber=page,filter=fil,sortColumns=f'SECURITY_CODE,{field},END_DATE',sortTypes='1,1,1',source='WEB',client='WEB');url='https://datacenter-web.eastmoney.com/api/data/v1/get?'+urllib.parse.urlencode(params);fn=folder/('closing_probe.json' if closing else f'page_{page:04d}.json')
 if fn.exists():
  if not closing:
   prior=records.get(page);assert prior is not None,'Cached page has no successful SHA journal; stop for review';assert hashlib.sha256(fn.read_bytes()).hexdigest()==prior['sha256']
  b=fn.read_bytes()
 else:
  for attempt in range(2):
   if stop.is_set() or G.exists():stop.set();raise RuntimeError('Global stop; no new request')
   try:
    time.sleep(.3)
    if stop.is_set() or G.exists():stop.set();raise RuntimeError('Global stop; no new request')
    with urllib.request.urlopen(url,timeout=45) as res:b=res.read()
    d=json.loads(b);result(d);break
   except (urllib.error.HTTPError,urllib.error.URLError) as e:
    if (isinstance(e,urllib.error.HTTPError) and e.code in [401,403,429]) or any(t in str(e).lower() for t in ['401','403','429','forbidden','denied','unauthorized','tunnel connection failed','tunnel refused','proxy authentication required']):halt('access_refusal',j['id'],url,repr(e));raise
    if isinstance(e,urllib.error.HTTPError) and e.code<500:raise
    if attempt:raise
    time.sleep(2)
   except (TimeoutError,ConnectionError):
    if attempt:raise
    time.sleep(2)
  fn.write_bytes(b)
 d=json.loads(b);rr=result(d);count=rr['count'];pages=rr['pages'];rows=rr.get('data') or []
 if expected is not None and (count,pages)!=expected:halt('source_drift',j['id'],url,'Count/pages changed');raise RuntimeError('Source drift')
 item={'file':fn.name,'url':url,'sha256':hashlib.sha256(b).hexdigest(),'rows':len(rows),'count':count,'pages':pages,'page':page}
 if not closing:
  records[page]=item;(folder/'page_manifest.json').write_text(json.dumps(sorted(records.values(),key=lambda x:x['page']),indent=2))
 return rr,rows,item
def run(j):
 if stop.is_set():raise RuntimeError('Global stop; no next job')
 folder=O/j['id'];folder.mkdir(exist_ok=True);mf=folder/'COMPLETE.json'
 if mf.exists():
  old=json.loads(mf.read_text());assert hashlib.sha256((folder/'all_raw.json').read_bytes()).hexdigest()==old['sha256'];return old
 records={x['page']:x for x in json.loads((folder/'page_manifest.json').read_text())} if (folder/'page_manifest.json').exists() else {}
 first,rows,item=get(j,1,folder,records);rows=list(rows);expected=(first['count'],first['pages']);print('PROBE',j['id'],expected,flush=True)
 for page in range(2,first['pages']+1):rows.extend(get(j,page,folder,records,expected)[1])
 if len(rows)!=first['count']:halt('validation_anomaly',j['id'],'','Row count mismatch');raise RuntimeError('Row count mismatch')
 keys=[(x['SECURITY_CODE'],x[j['datefield']],x['END_DATE']) for x in rows]
 if keys!=sorted(keys) or len(keys)!=len(set(keys)):halt('validation_anomaly',j['id'],'','Unsorted or duplicate source keys');raise RuntimeError('Source key anomaly')
 if not all(x['SECURITY_CODE'] in j['codes'] and '2009-01-01'<=x[j['datefield']][:10]<=j['end'] for x in rows):halt('validation_anomaly',j['id'],'','Source scope mismatch');raise RuntimeError('Source scope mismatch')
 closing,_,ci=get(j,1,folder,records,expected,True)
 if closing.get('data')!=first.get('data'):halt('source_drift',j['id'],ci['url'],'First-page contents changed');raise RuntimeError('First-page drift')
 raw=folder/'all_raw.json';raw.write_text(json.dumps(rows,ensure_ascii=False));out={'status':'complete','job':j,'rows':len(rows),'pages':first['pages'],'sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'closing_probe':ci,'all_page_sha_verified':True};mf.write_text(json.dumps(out,indent=2));print('COMPLETE',j['id'],len(rows),flush=True);return out
results=[];errors=[]
with concurrent.futures.ThreadPoolExecutor(2) as ex:
 pending={};it=iter(jobs)
 for _ in range(2):
  j=next(it,None)
  if j:pending[ex.submit(run,j)]=j['id']
 while pending:
  done,_=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
  for fu in done:
   job=pending.pop(fu)
   try:results.append(fu.result())
   except Exception as e:errors.append({'job':job,'error':repr(e)});stop.set();print('STOP',job,repr(e),flush=True)
   if not stop.is_set():
    j=next(it,None)
    if j:pending[ex.submit(run,j)]=j['id']
summary={'status':'complete' if len(results)==18 and not errors else 'incomplete','results':results,'errors':errors,'stop_reason':stop_reason};(R/'CAPTURE_COMPLETE.json').write_text(json.dumps(summary,indent=2));assert summary['status']=='complete','Capture incomplete; no merge allowed'
