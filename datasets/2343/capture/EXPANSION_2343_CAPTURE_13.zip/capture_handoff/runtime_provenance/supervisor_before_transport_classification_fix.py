"""Single supervised Mac capture run. Never clears stops or resumes a refused run."""
from pathlib import Path
import argparse,subprocess,sys,json,time,datetime,shutil,os,fcntl
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
if not a.execute:print('OFFLINE ONLY: explicit --execute required');raise SystemExit(0)
lock=(R/'.capture_lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
G=R/'GLOBAL_STOP.json'
assert not G.exists(),'Prior global stop must not be removed or bypassed'
assert not (R/'SUPERVISED_EXECUTION.json').exists(),'Existing execution must be reviewed, never started twice'
assert shutil.disk_usage(R).free>2*1024**3,'Insufficient initial disk reserve'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def stop(reason):
 try:
  with G.open('x') as f:json.dump({'source':'supervisor','utc':now(),'reason':reason,'action':'STOP_ALL_SOURCES; no automatic restart'},f,indent=2)
 except FileExistsError:pass
logs={k:(R/(k+'_capture.log')).open('w') for k in ['prices','holders']}
commands={'prices':[sys.executable,str(R/'prices/capture_prices.py'),'--execute','--output',str(R/'prices/price_capture')], 'holders':[sys.executable,str(R/'holders/capture_early.py'),'--execute','--operator','root-mac-public-download']}
start=time.time();procs={k:subprocess.Popen(v,cwd=R,stdout=logs[k],stderr=subprocess.STDOUT) for k,v in commands.items()};halt_at=None;last_print=-1
while True:
 exits={k:v.poll() for k,v in procs.items()}
 if any(v is not None and v!=0 for v in exits.values()):stop('collector_exit_nonzero')
 if shutil.disk_usage(R).free<1024**3:stop('disk_reserve_below_1GiB')
 if G.exists() and halt_at is None:halt_at=time.time();print('GLOBAL_STOP observed; supervising all in-flight requests to termination',flush=True)
 if halt_at is not None and time.time()-halt_at>180:
  for v in procs.values():
   if v.poll() is None:v.terminate()
 successes=list((R/'prices/price_capture/success').glob('*.json'));holder_jobs=list((R/'holders/captured').glob('*/COMPLETE.json'))
 progress={'utc':now(),'elapsed_seconds':round(time.time()-start,1),'child_pids':{k:v.pid for k,v in procs.items()},'child_exit_codes':exits,'price_success_files':len(successes),'holder_completed_jobs':len(holder_jobs),'global_stop':G.exists(),'free_bytes':shutil.disk_usage(R).free}
 (R/'CAPTURE_PROGRESS.json').write_text(json.dumps(progress,indent=2)+'\n')
 if int((time.time()-start)//60)!=last_print:last_print=int((time.time()-start)//60);print(json.dumps(progress),flush=True)
 if all(v is not None for v in exits.values()):break
 time.sleep(2)
for f in logs.values():f.close()
result={**progress,'status':'complete' if all(v==0 for v in exits.values()) and not G.exists() else 'stopped_or_incomplete','all_collectors_terminated':True,'network_settings_changed':False,'original1494_requested':False}
(R/'SUPERVISED_EXECUTION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(0 if result['status']=='complete' else 2)
