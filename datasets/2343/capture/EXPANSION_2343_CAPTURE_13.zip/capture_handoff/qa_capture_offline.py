"""Offline raw/factor/CSV and holder-page QA; no network, never upgrades incomplete status."""
from pathlib import Path
import json,csv,hashlib,math,bisect,subprocess,collections
R=Path(__file__).resolve().parent;P=R/'prices/price_capture'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
prices=[];maxerr=0;errors=[]
for s in sorted((P/'success').glob('*.json')):
 j=json.loads(s.read_text());code=j['code']
 try:
  rp=P/'raw_prices'/f'{code}_full.js';fp=P/'raw_prices'/f'{code}_hfq.txt'
  assert sha(rp)==j['raw_sha256'] and sha(fp)==j['factor_sha256']
  raw=json.loads(subprocess.check_output(['node',str(R/'prices/sina_decoder.js'),str(rp)],stderr=subprocess.PIPE,timeout=60))
  t=fp.read_text();f=json.JSONDecoder().raw_decode(t[t.index('{'):])[0];factors=sorted((v['d'],float(v['f'])) for v in f['data']);dates=[v[0] for v in factors];assert all(math.isfinite(v) and v>0 for _,v in factors)
  expected=[]
  for row in raw:
   day=row['date'][:10];vals={k:float(row[k]) for k in ['open','high','low','close','volume']};assert all(math.isfinite(v) for v in vals.values())
   if min(vals[k] for k in ['open','high','low','close'])<=0 or not '2009-01-01'<=day<='2026-10-30':continue
   i=bisect.bisect_right(dates,day)-1;assert not factors or i>=0;factor=factors[i][1] if i>=0 else 1.
   expected.append({'date':day,**{k:vals[k]*factor for k in ['open','high','low','close']},'volume':vals['volume'],'adjustment_factor':factor,**{'raw_'+k:vals[k] for k in ['open','high','low','close']}})
  expected.sort(key=lambda x:x['date']);assert len(expected)==j['rows'] and len({x['date'] for x in expected})==len(expected)
  if j['status']=='ok':
   cp=P/'prices'/f'{code}.csv';assert sha(cp)==j['csv_sha256'];saved=list(csv.DictReader(cp.open()));assert len(saved)==len(expected)
   for x,y in zip(saved,expected):
    assert x['date']==y['date']
    for k in y:
     if k=='date':continue
     err=abs(float(x[k])-y[k]);maxerr=max(maxerr,err);assert err==0,(k,err)
  else:assert j['status']=='empty_no_price' and not expected
  prices.append({'code':code,'status':j['status'],'rows':j['rows'],'raw_sha256':j['raw_sha256'],'factor_sha256':j['factor_sha256'],'csv_sha256':j.get('csv_sha256')})
 except Exception as e:errors.append({'code':code,'error':str(e)})
jobs=json.loads((R/'holders/REQUEST_PLAN.json').read_text())['jobs'];holders=[]
for job in jobs:
 folder=R/'holders/captured'/job['id'];journal=folder/'page_manifest.json'
 if not journal.exists():continue
 rows=[];records=json.loads(journal.read_text());counts=set();pages=set()
 for x in records:
  path=folder/x['file'];assert sha(path)==x['sha256'];d=json.loads(path.read_text());q=d.get('result') or {'count':0,'pages':0,'data':[]};a=q.get('data') or []
  assert (q['count'],q['pages'],len(a))==(x['count'],x['pages'],x['rows']);counts.add(q['count']);pages.add(q['pages']);rows.extend(a)
 assert len(counts)==len(pages)==1
 count=next(iter(counts));total=next(iter(pages));keys=[(x['SECURITY_CODE'],x[job['datefield']],x['END_DATE']) for x in rows]
 assert keys==sorted(keys) and len(keys)==len(set(keys));assert all(x['SECURITY_CODE'] in job['codes'] and job['start']<=x[job['datefield']][:10]<=job['end'] for x in rows)
 complete=(folder/'COMPLETE.json').exists()
 if complete:
  assert len(rows)==count and len(records)==max(total,1)
  first=json.loads((folder/'page_0001.json').read_text());closing=json.loads((folder/'closing_probe.json').read_text());assert first.get('result')==closing.get('result')
  m=json.loads((folder/'COMPLETE.json').read_text());assert sha(folder/'all_raw.json')==m['sha256'] and json.loads((folder/'all_raw.json').read_text())==rows
 holders.append({'job':job['id'],'complete':complete,'registered_pages':len(records),'rows':len(rows),'expected_rows':count,'expected_pages':total,'missing_A_rows':sum(x.get('HOLDER_A_NUM') is None for x in rows) if job['table']=='RPT_F10_EH_HOLDERNUM' else None,'A_values_not_replaced_by_TOTAL':True})
report={'status':'PASS_AVAILABLE_DATA' if not errors else 'QA_FAILED','price_validated_stocks':len(prices),'price_rows':sum(x['rows'] for x in prices),'price_status_counts':dict(collections.Counter(x['status'] for x in prices)),'raw_to_csv_max_error':maxerr,'prices':prices,'price_qa_errors':errors,'holder_jobs_validated':len(holders),'holder_complete_jobs':sum(x['complete'] for x in holders),'holders':holders,'network_used':False,'models_rebuilt':False,'A_TOTAL_policy':'Raw F10 fields preserved; missing A counted, never filled with TOTAL. No merge into DET performed in capture QA.'}
(R/'OFFLINE_CAPTURE_QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['prices','holders']},ensure_ascii=False))
raise SystemExit(1 if errors else 0)
