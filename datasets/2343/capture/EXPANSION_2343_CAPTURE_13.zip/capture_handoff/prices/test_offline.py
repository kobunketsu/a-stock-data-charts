"""Offline contract tests only; never calls a network endpoint."""
from pathlib import Path
import ast,urllib.error,threading,hashlib,json,tempfile,csv,subprocess,sys,runpy,io
H=Path(__file__).resolve().parent; tree=ast.parse((H/'capture_prices.py').read_text()); ns={'re':__import__('re')}; exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='refusal'],type_ignores=[]),'refusal','exec'),ns)
for code in [401,403,429]:
 assert ns['refusal'](urllib.error.HTTPError('https://example.invalid',code,'blocked',None,None))
 assert ns['refusal'](urllib.error.URLError(OSError('Tunnel connection failed: '+str(code)+' Forbidden')))
assert not ns['refusal'](TimeoutError('timed out'))
print('PASS: HTTP and nested URLError refusal detection; syntax/dry-run only. Real Mac fetch remains unexecuted.')
